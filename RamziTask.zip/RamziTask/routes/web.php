<?php


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use Illuminate\Http\Request;
Route::get('/', function () {
    return view('userview');
});

/* The path for the blade file**/
Route::view('/userview', "userview");

/* Home controller file for where to submit the form*/

Route::post('/homecontroller', 'App\Http\Controllers\HomeController@formSubmit');

/*Route::post('/homecontroller', function (Request $req) {
  $str = $req->input('integers');
$countedIntegers = array_count_values(explode(",",$str));
dd($countedIntegers);
});*/
