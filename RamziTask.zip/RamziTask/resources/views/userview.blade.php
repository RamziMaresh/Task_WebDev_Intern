<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title> Internship Task</title>
    <base href="{{ URL::asset('/') }}" target="_blank">

      <!-- The Bootsrap file and the main css file -->
    <link rel="stylesheet" href="{{ URL('/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ URL('/css/minStyle.css') }}">

      <!-- The jquery -->
    <script src ="{{ URL('js/jquery-3.6.0.min.js') }}"> </script>

    <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

  </head>
  <body>
    <div class="container">

<br><br><h2 >Internship Task For Ramzi Maresh </h2><br>
<table>
  <tr>
    <td>Name</td>
    <td>Ramzi Ahmed</td>
  </tr>

  <tr>
    <td>Task Start</td>
    <td>5-1-2022 12:00PM</td>
  </tr>
  <tr>
    <td>Task End</td>
    <td>6-1-2022 12:00PM</td>
  </tr>
</table>
<br>
<br>

    </div>
    <div class="container">
      <h5>Enter Integer Values:</h5></b>

      <form action="homecontroller" method="POST">
        <input type="text" name="integers" value="">
      @csrf
    </br>
    <button type="submit" name="button"> Show result</button>
</form>



    <!--  jS bootstrap -->
    <script src ="{{ URL('js/bootstrap.min.js') }}"> </script>
    <!--  jS bootstrap popper -->
    <script src ="{{ URL('js/popper.min.js') }}"> </script>

  </body>
</html>
