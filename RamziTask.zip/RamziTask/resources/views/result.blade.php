<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    
    <ul>
        @foreach($countedIntegers as $key => $value)
        <li>{{$key}} : {{$value}} occurrences</li>
        @endforeach
</ul>
  </body>
</html>
