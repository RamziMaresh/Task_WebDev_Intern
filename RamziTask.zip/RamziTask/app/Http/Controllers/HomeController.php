<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    // Home Page
    public function formSubmit(Request $req)
    {

    $str = $req->input('integers');
    $countedIntegers = array_count_values(explode(",",$str));
    /*dd($countedIntegers);*/
    return view('result', compact('countedIntegers'));
    }
}
