<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    
    <ul>
        <?php $__currentLoopData = $countedIntegers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($key); ?> : <?php echo e($value); ?> occurrences</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
  </body>
</html>
<?php /**PATH C:\laragon\www\RamziTask\resources\views/result.blade.php ENDPATH**/ ?>